from fastapi import FastAPI
from .api import tutor_router
from .database.mongodb_ops import check_db_connection
import logging

logging.basicConfig(level=logging.INFO)

# Run database check on startup for verification
check_db_connection()

app = FastAPI(
    title="AI Guru J Backend",
    description="API for the 3D AI Tutor, handling all AI, NLP, and Speech Processing.",
    version="1.0.0"
)

# Include the router for all tutor-related endpoints
app.include_router(tutor_router.router, prefix="/api/tutor", tags=["Tutor Interaction"])

@app.get("/")
def read_root():
    """Simple health check endpoint."""
    return {"message": "AI Guru J Backend is running."}

# To run the app: uvicorn app.main:app --reload