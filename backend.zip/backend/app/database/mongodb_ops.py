from pymongo import MongoClient
from ..core.config import settings
import datetime
import logging

logging.basicConfig(level=logging.INFO)

# --- Global Connection Setup ---
# Initialize client globally to reuse connection
try:
    # Use a connection string from settings (e.g., MongoDB Atlas URI)
    client = MongoClient(settings.MONGODB_URI) 
    db = client.ai_guru_j_db # Database name
    interactions_collection = db.interactions
    logging.info("MongoDB client initialized.")
except Exception as e:
    logging.error(f"⚠️ Warning: MongoDB client failed to initialize: {e}")
    client = None
    interactions_collection = None


def check_db_connection():
    """Verifies connection to MongoDB Atlas."""
    if client is None:
        logging.error("❌ MongoDB client is not initialized.")
        return False
        
    try:
        # Pings the database to check the connection
        client.admin.command('ping') 
        logging.info("✅ MongoDB connection successful.")
        return True
    except Exception as e:
        logging.error(f"❌ MongoDB connection failed: {e}")
        return False

def log_interaction(user_query: str, ai_response_text: str):
    """Logs the user query and AI response to MongoDB."""
    if interactions_collection is None:
        logging.error("❌ Database collection is not available for logging.")
        return

    interaction_data = {
        "user_query": user_query,
        "ai_response": ai_response_text,
        "timestamp": datetime.datetime.now(datetime.timezone.utc),
    }

    try:
        result = interactions_collection.insert_one(interaction_data)
        logging.info(f"✅ Interaction logged with ID: {result.inserted_id}")
    except Exception as e:
        logging.error(f"❌ Failed to log interaction to MongoDB: {e}")